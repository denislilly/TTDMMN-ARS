"""
Graph-based Social Propagation Module (GSPM), Section 3.6.

Each article is associated with a propagation graph G = (V, E, A) where
nodes represent users and articles, edges represent sharing events, and
A is a weighted adjacency matrix. Two graph-convolutional layers are
applied when graph data is present (FakeNewsNet only):

    H^(l) = sigma( D~^{-1/2} A~ D~^{-1/2} H^{(l-1)} W^{(l)}_TT )     (Eq. 9)

with A~ = A + I (self-loops) and D~ its degree matrix. W^{(l)}_TT is a
TT-structured weight (Section 3.4-3.6: "the entire multimodal
architecture, including ... graph convolution layers"). If there is no
propagation graph, h_social defaults to a zero placeholder, achieving
modality-graceful degradation under softmax-normalised fusion (Section
3.6 / 3.7).

Two backbones are supported, matching the "Implement GraphSAGE or Graph
Attention Network matching the paper" requirement:
  - `gcn`   : the literal Eq. 9 symmetric-normalised spectral GCN, TT-
              weighted (default; matches the manuscript equation).
  - `sage`  : GraphSAGE-style mean-aggregation with a TT-weighted
              transform, for the cross-modal / heterogeneous-graph
              ablation variants.
  - `gat`   : single-head graph-attention aggregation with a TT-weighted
              transform, for the GAT ablation variant.

All three support follower graphs, propagation (retweet/share) graphs,
and heterogeneous (user+article, mixed edge type) graphs -- the caller
is responsible for constructing the appropriate adjacency/edge-index
before calling forward(); the module itself is graph-topology-agnostic
beyond the standard (adjacency, features) or (edge_index, features)
interfaces used below.
"""

from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from models.tensor_train import TTLinear


def normalize_adjacency(adj: torch.Tensor) -> torch.Tensor:
    """A~ = A + I ; D~^{-1/2} A~ D~^{-1/2}   (Eq. 9 normalisation)."""
    n = adj.shape[-1]
    eye = torch.eye(n, device=adj.device, dtype=adj.dtype).expand_as(adj)
    a_tilde = adj + eye
    deg = a_tilde.sum(dim=-1)  # (..., n)
    deg_inv_sqrt = deg.clamp(min=1e-12).pow(-0.5)
    d_mat = torch.diag_embed(deg_inv_sqrt)
    return d_mat @ a_tilde @ d_mat


class TTGraphConvLayer(nn.Module):
    """Single TT-weighted spectral graph-convolution layer (Eq. 9)."""

    def __init__(self, in_features: int, out_features: int, tt_rank: int = 4, tt_order: int = 2):
        super().__init__()
        self.linear = TTLinear(in_features, out_features, rank=tt_rank, order=tt_order)

    def forward(self, h: torch.Tensor, adj_norm: torch.Tensor) -> torch.Tensor:
        # h: (B, N, F_in), adj_norm: (B, N, N)
        support = self.linear(h)          # (B, N, F_out) -- W_TT applied first
        out = torch.bmm(adj_norm, support)  # D~^-1/2 A~ D~^-1/2 (H W)
        return out


class TTGraphSAGELayer(nn.Module):
    """Mean-aggregation GraphSAGE layer with a TT-weighted transform,
    used for the GraphSAGE ablation variant."""

    def __init__(self, in_features: int, out_features: int, tt_rank: int = 4, tt_order: int = 2):
        super().__init__()
        self.self_linear = TTLinear(in_features, out_features, rank=tt_rank, order=tt_order)
        self.neigh_linear = TTLinear(in_features, out_features, rank=tt_rank, order=tt_order)

    def forward(self, h: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        deg = adj.sum(dim=-1, keepdim=True).clamp(min=1.0)
        neigh_mean = torch.bmm(adj, h) / deg
        return self.self_linear(h) + self.neigh_linear(neigh_mean)


class TTGraphAttentionLayer(nn.Module):
    """Single-head Graph Attention (GAT) layer with a TT-weighted
    transform, used for the GAT ablation variant."""

    def __init__(self, in_features: int, out_features: int, tt_rank: int = 4, tt_order: int = 2):
        super().__init__()
        self.linear = TTLinear(in_features, out_features, rank=tt_rank, order=tt_order)
        self.attn_src = nn.Parameter(torch.randn(out_features) * 0.01)
        self.attn_dst = nn.Parameter(torch.randn(out_features) * 0.01)
        self.leaky_relu = nn.LeakyReLU(0.2)

    def forward(self, h: torch.Tensor, adj_mask: torch.Tensor) -> torch.Tensor:
        Wh = self.linear(h)  # (B, N, F_out)
        e_src = (Wh * self.attn_src).sum(-1, keepdim=True)     # (B, N, 1)
        e_dst = (Wh * self.attn_dst).sum(-1, keepdim=True)     # (B, N, 1)
        e = e_src + e_dst.transpose(1, 2)                      # (B, N, N)
        e = self.leaky_relu(e)
        neg_inf = torch.finfo(e.dtype).min
        e = e.masked_fill(adj_mask <= 0, neg_inf)
        alpha = F.softmax(e, dim=-1)
        return torch.bmm(alpha, Wh)


class GraphSocialPropagationModule(nn.Module):
    """
    Two-layer TT-structured graph encoder (Section 3.6). Consumes a
    dense adjacency matrix (padded/batched) and node features, and
    returns a pooled social-context representation h_social in
    R^{out_dim}. When no propagation graph is available for a sample,
    `forward(None, ...)` (or an all-zero adjacency) returns a zero
    placeholder, giving modality-graceful degradation.
    """

    def __init__(
        self,
        in_features: int,
        hidden_features: int = 256,
        out_features: int = 256,
        backbone: str = "gcn",
        tt_rank: int = 4,
        tt_order: int = 2,
        dropout: float = 0.1,
    ):
        super().__init__()
        assert backbone in ("gcn", "sage", "gat")
        self.backbone = backbone
        self.out_features = out_features

        layer_cls = {"gcn": TTGraphConvLayer, "sage": TTGraphSAGELayer, "gat": TTGraphAttentionLayer}[backbone]
        self.layer1 = layer_cls(in_features, hidden_features, tt_rank=tt_rank, tt_order=tt_order)
        self.layer2 = layer_cls(hidden_features, out_features, tt_rank=tt_rank, tt_order=tt_order)
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        node_features: Optional[torch.Tensor],
        adjacency: Optional[torch.Tensor],
        node_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Args:
            node_features: (B, N, F_in) or None if no graph is available
                for the whole batch (returns zero placeholder).
            adjacency: (B, N, N) binary/weighted adjacency, or None.
            node_mask: (B, N) 1 for real nodes / 0 for padding (used for
                masked mean-pooling over nodes into a single vector).

        Returns:
            h_social in R^{B, out_features}.
        """
        if node_features is None or adjacency is None:
            raise ValueError("Use `zero_placeholder` for missing-graph samples instead of calling forward(None,...)")

        adj_norm = normalize_adjacency(adjacency) if self.backbone == "gcn" else adjacency

        h = self.layer1(node_features, adj_norm)
        h = F.relu(h)
        h = self.dropout(h)
        h = self.layer2(h, adj_norm)
        h = F.relu(h)

        if node_mask is not None:
            mask = node_mask.unsqueeze(-1).to(h.dtype)
            summed = (h * mask).sum(dim=1)
            count = mask.sum(dim=1).clamp(min=1.0)
            pooled = summed / count
        else:
            pooled = h.mean(dim=1)
        return self.dropout(pooled)

    def zero_placeholder(self, batch_size: int, device, dtype=torch.float32) -> torch.Tensor:
        """Section 3.6: 'If there is no propagation graph, the default
        h_social is a placeholder with a value of zero.'"""
        return torch.zeros(batch_size, self.out_features, device=device, dtype=dtype)
