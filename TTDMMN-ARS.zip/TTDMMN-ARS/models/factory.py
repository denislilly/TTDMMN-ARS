"""Build a TTDMMNARS model (and matching TrainerConfig) from a loaded
YAML config dict (see utils/config.py::load_config)."""

from __future__ import annotations

from typing import Any, Dict

from models.ttdmmn_ars import TTDMMNARS, TTDMMNARSConfig
from trainers.trainer import TrainerConfig


def build_model_config(cfg: Dict[str, Any]) -> TTDMMNARSConfig:
    m = cfg["model"]
    return TTDMMNARSConfig(
        text_pretrained_name=m["text"]["pretrained_name"],
        text_dim=m["text"]["dim"],
        text_tt_rank=m["text"]["tt_rank"],
        text_tt_order=m["text"]["tt_order"],
        use_text_encoder_pretrained_weights=m["text"]["use_pretrained_weights"],
        use_visual=m["visual"]["enabled"],
        visual_dim=m["visual"]["dim"],
        visual_rank_ratio=m["visual"]["rank_ratio"],
        visual_tt_rank=m["visual"]["tt_rank"],
        visual_tt_order=m["visual"]["tt_order"],
        visual_backbone=m["visual"]["backbone"],
        use_visual_pretrained_weights=m["visual"]["use_pretrained_weights"],
        use_graph=m["graph"]["enabled"],
        graph_in_features=m["graph"]["in_features"],
        graph_hidden=m["graph"]["hidden"],
        graph_dim=m["graph"]["dim"],
        graph_backbone=m["graph"]["backbone"],
        graph_tt_rank=m["graph"]["tt_rank"],
        graph_tt_order=m["graph"]["tt_order"],
        fusion_strategy=m["fusion"]["strategy"],
        fusion_pair_dim=m["fusion"]["pair_dim"],
        fusion_out_dim=m["fusion"]["out_dim"],
        fusion_num_heads=m["fusion"]["num_heads"],
        classifier_hidden=m["classifier"]["hidden"],
        num_classes=m["classifier"]["num_classes"],
        classifier_tt_rank=m["classifier"]["tt_rank"],
        classifier_tt_order=m["classifier"]["tt_order"],
        dropout=m["dropout"],
    )


def build_model(cfg: Dict[str, Any]) -> TTDMMNARS:
    return TTDMMNARS(build_model_config(cfg))


def build_trainer_config(cfg: Dict[str, Any]) -> TrainerConfig:
    t = cfg["training"]
    a = cfg["ars"]
    log = cfg["logging"]
    return TrainerConfig(
        lr_max=t["lr_max"],
        lr_min=t["lr_min"],
        weight_decay=t["weight_decay"],
        adam_beta1=t["adam_beta1"],
        adam_beta2=t["adam_beta2"],
        num_epochs=t["num_epochs"],
        warmup_steps=t["warmup_steps"],
        grad_accum_steps=t["grad_accum_steps"],
        batch_size=cfg["data"]["batch_size"],
        max_grad_norm=t["max_grad_norm"],
        early_stopping_patience=t["early_stopping_patience"],
        use_focal_loss=t["use_focal_loss"],
        focal_gamma=t["focal_gamma"],
        focal_alpha=t["focal_alpha"],
        ars_lambda_max=a["lambda_max"],
        ars_warmup_steps=a["warmup_steps"],
        ars_truncation_eps=a["truncation_eps"],
        checkpoint_dir=log["checkpoint_dir"],
        log_dir=log["log_dir"],
        run_name=log["run_name"],
        use_tensorboard=log["use_tensorboard"],
        use_wandb=log["use_wandb"],
        log_every_n_steps=log["log_every_n_steps"],
    )
