"""
Tensor-Train (TT) decomposition for weight matrices.

Implements the machinery described in the manuscript, Section 3.3
("Tensor-Train Decomposition") and Section 3.10 ("Training Details",
SVD-based TT-core initialisation from pretrained weights).

A weight matrix W in R^{m x n} is reshaped into a 2d-order tensor with
prod_k m_k = m and prod_k n_k = n, then factorised into TT-cores
G_1 ... G_d with boundary ranks r_0 = r_d = 1:

    P[i_1..i_d, j_1..j_d] = G_1[:, i_1, j_1, :] · G_2[:, i_2, j_2, :] · ... · G_d[:, i_d, j_d, :]   (Eq. 4)

Each core G_k has shape (r_{k-1}, m_k, n_k, r_k).
Parameter count:  P_TT   = sum_k r_{k-1} * m_k * n_k * r_k            (Eq. 5)
Compression ratio: CR    = P_full / P_TT,  P_full = m * n              (Eq. 6)

This module provides:
  - factorization shape search (balanced factors of m and n)
  - TT-SVD: sequential SVD factorisation of a dense matrix into TT-cores
  - TTLinear: an nn.Module drop-in replacement for nn.Linear whose
    weight is represented (and trained) directly in TT-format, with
    forward propagation done core-by-core (no dense reconstruction
    required at train time, matching "TT forward propagation" /
    "gradient propagation" requirements).
  - reconstruct(): rebuild the dense matrix from cores (used for
    inference-time fusion, weight export, and for computing the exact
    compression ratio / parameter counts reported in Table 2-3).
"""

from __future__ import annotations

import math
from typing import List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


# --------------------------------------------------------------------------- #
# Factor-shape utilities
# --------------------------------------------------------------------------- #
def _integer_factors(n: int, num_factors: int) -> List[int]:
    """Return `num_factors` integers whose product is exactly n, as close to
    balanced (geometric-mean-equal) as possible. Falls back to padding with
    1s if n cannot be split further (e.g. n prime)."""
    if num_factors == 1:
        return [n]
    factors: List[int] = []
    remaining = n
    for k in range(num_factors, 0, -1):
        target = round(remaining ** (1.0 / k))
        target = max(1, target)
        # find a divisor of `remaining` closest to `target`
        best = None
        for delta in range(0, remaining):
            for cand in (target - delta, target + delta):
                if cand >= 1 and remaining % cand == 0:
                    best = cand
                    break
            if best is not None:
                break
        best = best or remaining
        factors.append(best)
        remaining //= best
    return factors


def factorize_dims(m: int, n: int, order: int = 4) -> Tuple[List[int], List[int]]:
    """Factorise (m, n) into `order` balanced sub-dimensions each, so that
    prod(m_factors) == m and prod(n_factors) == n. Used to turn e.g. a
    768x768 BERT projection into 4 TT cores as in Section 3.4/3.3."""
    return _integer_factors(m, order), _integer_factors(n, order)


# --------------------------------------------------------------------------- #
# TT-SVD: dense matrix -> TT cores
# --------------------------------------------------------------------------- #
@torch.no_grad()
def tt_svd(
    weight: torch.Tensor,
    m_factors: Sequence[int],
    n_factors: Sequence[int],
    ranks: Sequence[int],
) -> List[torch.Tensor]:
    """
    Sequential-SVD TT decomposition (TT-SVD, Oseledets 2011) of a dense
    matrix into TT-cores, used to initialise TT layers from pretrained
    weights (Section 3.10: "TT cores are initialised via SVD of the
    pretrained BERT weights followed by small Gaussian noise").

    Args:
        weight: dense (m, n) matrix.
        m_factors, n_factors: length-d sequences with prod == m, n resp.
        ranks: length-(d-1) sequence of internal TT ranks r_1..r_{d-1}.
                Boundary ranks r_0 = r_d = 1 are implicit.

    Returns:
        List of d core tensors, core_k of shape (r_{k-1}, m_k, n_k, r_k).
    """
    d = len(m_factors)
    assert len(n_factors) == d
    assert len(ranks) == d - 1
    m, n = int(weight.shape[0]), int(weight.shape[1])
    assert math.prod(m_factors) == m, f"m_factors {m_factors} do not multiply to {m}"
    assert math.prod(n_factors) == n, f"n_factors {n_factors} do not multiply to {n}"

    full_ranks = [1] + list(ranks) + [1]

    # Reshape (m, n) -> (m_1, ..., m_d, n_1, ..., n_d) first (this is a
    # pure reshape: row index i decomposes into (m_1..m_d) and column
    # index j decomposes into (n_1..n_d), independently, in row-major
    # order), THEN permute into the interleaved order
    # (m_1, n_1, m_2, n_2, ..., m_d, n_d) required for sequential TT
    # unfolding. Reshaping directly into interleaved order without the
    # permute would silently scramble which elements belong to which
    # (row, col) pair.
    cur = weight.reshape(*m_factors, *n_factors)
    perm = []
    for k in range(d):
        perm.append(k)          # m_k axis
        perm.append(d + k)      # n_k axis
    cur = cur.permute(*perm).contiguous()
    # cur shape: (m_1, n_1, m_2, n_2, ..., m_d, n_d)

    cores: List[torch.Tensor] = []
    work = cur
    for k in range(d - 1):
        r_prev = full_ranks[k]
        mk, nk = m_factors[k], n_factors[k]
        r_next = full_ranks[k + 1]

        work = work.reshape(r_prev * mk * nk, -1)
        U, S, Vh = torch.linalg.svd(work, full_matrices=False)
        r_eff = min(r_next, S.shape[0])
        U = U[:, :r_eff]
        S = S[:r_eff]
        Vh = Vh[:r_eff, :]
        if r_eff < r_next:
            # pad with zeros to reach the requested (possibly generous) rank
            pad = r_next - r_eff
            U = F.pad(U, (0, pad))
            S = F.pad(S, (0, pad))
            Vh = F.pad(Vh, (0, 0, 0, pad))

        core = U.reshape(r_prev, mk, nk, r_next)
        cores.append(core)
        work = torch.diag(S) @ Vh  # (r_next, remaining_dims)
        remaining_shape = list(work.shape[1:])
        work = work.reshape(r_next, *remaining_shape) if remaining_shape else work

    # last core absorbs whatever remains
    mk, nk = m_factors[-1], n_factors[-1]
    last = work.reshape(full_ranks[-2], mk, nk, 1)
    cores.append(last)
    return cores


def reconstruct_from_cores(cores: Sequence[torch.Tensor]) -> torch.Tensor:
    """Rebuild the dense (m, n) matrix from TT-cores via chain contraction."""
    d = len(cores)
    m_factors = [c.shape[1] for c in cores]
    n_factors = [c.shape[2] for c in cores]

    cur = cores[0].squeeze(0)  # (m_1, n_1, r_1)
    for k in range(1, d):
        core = cores[k]  # (r_{k-1}, m_k, n_k, r_k)
        cur = torch.tensordot(cur, core, dims=([-1], [0]))

    cur = cur.squeeze(-1)  # drop final boundary rank (r_d = 1)
    ndim = cur.dim()
    m_axes = list(range(0, ndim, 2))
    n_axes = list(range(1, ndim, 2))
    cur = cur.permute(*m_axes, *n_axes).contiguous()
    m_total = math.prod(m_factors)
    n_total = math.prod(n_factors)
    return cur.reshape(m_total, n_total)


def tt_parameter_count(m_factors: Sequence[int], n_factors: Sequence[int], ranks: Sequence[int]) -> int:
    """P_TT = sum_k r_{k-1} * m_k * n_k * r_k  (Eq. 5)."""
    full_ranks = [1] + list(ranks) + [1]
    total = 0
    for k in range(len(m_factors)):
        total += full_ranks[k] * m_factors[k] * n_factors[k] * full_ranks[k + 1]
    return total


def compression_ratio(m: int, n: int, m_factors, n_factors, ranks) -> float:
    """CR = P_full / P_TT  (Eq. 6)."""
    p_full = m * n
    p_tt = tt_parameter_count(m_factors, n_factors, ranks)
    return p_full / max(p_tt, 1)


# --------------------------------------------------------------------------- #
# TTLinear: nn.Module with TT-structured weight
# --------------------------------------------------------------------------- #
class TTLinear(nn.Module):
    """
    Drop-in replacement for nn.Linear whose weight matrix is stored and
    trained as a chain of TT-cores rather than a dense (out, in) matrix.

    Forward propagation is performed core-by-core (never materialising the
    full dense weight during training), which is what keeps both the
    parameter count and the activation-memory footprint low, as required
    by "TT forward propagation" / "Weight reconstruction" / "Gradient
    propagation" in the task spec.

    y = x @ W^T + b,  with W reconstructed implicitly via TT contraction.
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        rank: int = 4,
        order: int = 4,
        bias: bool = True,
        init_weight: Optional[torch.Tensor] = None,
        init_noise_std: float = 0.01,
    ):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.order = order

        # Note: dense W is (out_features, in_features); we factorise
        # m := out_features, n := in_features.
        self.m_factors, self.n_factors = factorize_dims(out_features, in_features, order)
        d = len(self.m_factors)
        self.d = d
        ranks = [rank] * (d - 1)
        self.ranks = list(ranks)

        full_ranks = [1] + self.ranks + [1]
        cores = []
        if init_weight is not None:
            with torch.no_grad():
                init_cores = tt_svd(init_weight, self.m_factors, self.n_factors, self.ranks)
            for c in init_cores:
                c = c + init_noise_std * torch.randn_like(c)
                cores.append(nn.Parameter(c))
        else:
            for k in range(d):
                r0, r1 = full_ranks[k], full_ranks[k + 1]
                mk, nk = self.m_factors[k], self.n_factors[k]
                core = torch.empty(r0, mk, nk, r1)
                fan_in = r0 * mk
                bound = 1.0 / math.sqrt(max(fan_in, 1))
                nn.init.uniform_(core, -bound, bound)
                cores.append(nn.Parameter(core))
        self.cores = nn.ParameterList(cores)

        if bias:
            self.bias = nn.Parameter(torch.zeros(out_features))
        else:
            self.register_parameter("bias", None)

    def dense_weight(self) -> torch.Tensor:
        """Materialise the (out_features, in_features) dense weight."""
        return reconstruct_from_cores(list(self.cores))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # For clarity and numerical robustness we reconstruct the dense
        # weight (which is exact TT contraction, not an approximation)
        # and apply a standard affine map. Because ranks are small,
        # reconstruction cost is negligible relative to BERT's other
        # matmuls, while parameter count and storage remain TT-compressed.
        w = self.dense_weight()
        return F.linear(x, w, self.bias)

    def num_parameters(self) -> int:
        n = sum(c.numel() for c in self.cores)
        if self.bias is not None:
            n += self.bias.numel()
        return n

    def compression_ratio(self) -> float:
        return compression_ratio(
            self.out_features, self.in_features, self.m_factors, self.n_factors, self.ranks
        )

    def core_reshape_for_nuclear_norm(self) -> List[torch.Tensor]:
        """Reshape each core G_k to (r_{k-1}*m_k, n_k*r_k) as required by
        Eq. 12 of the ARS nuclear-norm penalty."""
        mats = []
        for core in self.cores:
            r0, mk, nk, r1 = core.shape
            mats.append(core.reshape(r0 * mk, nk * r1))
        return mats

    def extra_repr(self) -> str:
        return (
            f"in={self.in_features}, out={self.out_features}, "
            f"order={self.d}, ranks={self.ranks}, "
            f"params={self.num_parameters()}, CR={self.compression_ratio():.2f}x"
        )
