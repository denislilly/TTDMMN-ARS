"""
TTDMMN-ARS: Tensor-Train Decomposed Multi-Modal Neural Network with
Adaptive Rank Selection, Section 3.2.

Five sequentially-connected modules, matching Figure 1:
    1. TT-Compressed Text Encoder      (TCTE, Section 3.4)
    2. Tucker-Compressed Visual Feature Extractor (VFE, Section 3.5)
    3. TT-Structured Graph Social Propagation Module (GSPM, Section 3.6)
    4. Adaptive Cross-Modal Fusion Layer (ACFL, Section 3.7)
    5. TT-Linear Classification Head   (Section 3.9)

f(x; theta_TT) = sigma( g_fusion(h_text, h_visual, h_social; theta_TT) )   (Eq. 1)

Each sample x = (t, v, s): article text t, headline image v (optional),
social propagation graph s (optional). Missing visual/social modalities
fall back to zero placeholders, giving modality-graceful degradation
(Section 3.6/3.7) -- this is essential for WELFake/LIAR/COVID-19, which
are text-only, and for FakeNewsNet, whose graph coverage is partial.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import torch
import torch.nn as nn

from models.bert_encoder import TTCompressedTextEncoder
from models.vit_encoder import VisualFeatureExtractor
from models.graph_encoder import GraphSocialPropagationModule
from models.multimodal_fusion import build_fusion_layer
from models.classifier import TTClassificationHead
from models.tensor_train import TTLinear


@dataclass
class TTDMMNARSConfig:
    # Text (TCTE)
    text_pretrained_name: str = "bert-base-uncased"
    text_dim: int = 768
    text_tt_rank: int = 4
    text_tt_order: int = 4
    use_text_encoder_pretrained_weights: bool = True

    # Visual (VFE)
    use_visual: bool = True
    visual_dim: int = 512
    visual_rank_ratio: float = 0.5
    visual_tt_rank: int = 4
    visual_tt_order: int = 3
    visual_backbone: str = "resnet50"  # or "vit"
    use_visual_pretrained_weights: bool = True

    # Graph (GSPM)
    use_graph: bool = True
    graph_in_features: int = 128
    graph_hidden: int = 256
    graph_dim: int = 256
    graph_backbone: str = "gcn"  # gcn | sage | gat
    graph_tt_rank: int = 4
    graph_tt_order: int = 2

    # Fusion (ACFL)
    fusion_strategy: str = "acfl"  # acfl | early | late | tensor
    fusion_pair_dim: int = 128
    fusion_out_dim: int = 256
    fusion_num_heads: int = 4

    # Classifier
    classifier_hidden: int = 128
    num_classes: int = 2
    classifier_tt_rank: int = 4
    classifier_tt_order: int = 2

    dropout: float = 0.1


class TTDMMNARS(nn.Module):
    def __init__(self, cfg: TTDMMNARSConfig):
        super().__init__()
        self.cfg = cfg

        self.text_encoder = TTCompressedTextEncoder(
            pretrained_name=cfg.text_pretrained_name,
            tt_rank=cfg.text_tt_rank,
            tt_order=cfg.text_tt_order,
            dropout=cfg.dropout,
            init_from_pretrained=cfg.use_text_encoder_pretrained_weights,
        )

        if cfg.use_visual:
            self.visual_encoder = VisualFeatureExtractor(
                pretrained=cfg.use_visual_pretrained_weights,
                rank_ratio=cfg.visual_rank_ratio,
                tt_rank=cfg.visual_tt_rank,
                tt_order=cfg.visual_tt_order,
                out_dim=cfg.visual_dim,
                vit_backbone=(cfg.visual_backbone == "vit"),
                dropout=cfg.dropout,
            )
        else:
            self.visual_encoder = None

        if cfg.use_graph:
            self.graph_encoder = GraphSocialPropagationModule(
                in_features=cfg.graph_in_features,
                hidden_features=cfg.graph_hidden,
                out_features=cfg.graph_dim,
                backbone=cfg.graph_backbone,
                tt_rank=cfg.graph_tt_rank,
                tt_order=cfg.graph_tt_order,
                dropout=cfg.dropout,
            )
        else:
            self.graph_encoder = None

        self.fusion = build_fusion_layer(
            cfg.fusion_strategy,
            text_dim=cfg.text_dim,
            visual_dim=cfg.visual_dim,
            social_dim=cfg.graph_dim,
            out_dim=cfg.fusion_out_dim,
            dropout=cfg.dropout,
        )

        self.classifier = TTClassificationHead(
            in_dim=cfg.fusion_out_dim,
            hidden_dim=cfg.classifier_hidden,
            num_classes=cfg.num_classes,
            tt_rank=cfg.classifier_tt_rank,
            tt_order=cfg.classifier_tt_order,
            dropout=cfg.dropout,
        )

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        token_type_ids: Optional[torch.Tensor] = None,
        images: Optional[torch.Tensor] = None,
        graph_node_features: Optional[torch.Tensor] = None,
        graph_adjacency: Optional[torch.Tensor] = None,
        graph_node_mask: Optional[torch.Tensor] = None,
        has_visual: Optional[torch.Tensor] = None,
        has_graph: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """
        Returns raw logits (B,) for binary classification, or (B, C) for
        C > 2 classes (see TTClassificationHead).

        `has_visual` / `has_graph`: optional (B,) boolean tensors marking
        which samples in the batch actually have that modality present;
        samples without it get the zero placeholder for that branch
        (Section 3.6 modality-graceful degradation), applied per-sample
        rather than per-batch so mixed-availability batches are handled
        correctly.
        """
        B = input_ids.shape[0]
        device = input_ids.device

        h_text = self.text_encoder(input_ids, attention_mask=attention_mask, token_type_ids=token_type_ids)

        if self.visual_encoder is not None and images is not None:
            h_visual = self.visual_encoder(images)
            if has_visual is not None:
                zero = self.visual_encoder.zero_placeholder(B, device=device, dtype=h_visual.dtype)
                mask = has_visual.to(h_visual.dtype).unsqueeze(-1)
                h_visual = mask * h_visual + (1 - mask) * zero
        elif self.visual_encoder is not None:
            h_visual = self.visual_encoder.zero_placeholder(B, device=device)
        else:
            h_visual = torch.zeros(B, self.cfg.visual_dim, device=device)

        if self.graph_encoder is not None and graph_node_features is not None and graph_adjacency is not None:
            h_social = self.graph_encoder(graph_node_features, graph_adjacency, graph_node_mask)
            if has_graph is not None:
                zero = self.graph_encoder.zero_placeholder(B, device=device, dtype=h_social.dtype)
                mask = has_graph.to(h_social.dtype).unsqueeze(-1)
                h_social = mask * h_social + (1 - mask) * zero
        elif self.graph_encoder is not None:
            h_social = self.graph_encoder.zero_placeholder(B, device=device)
        else:
            h_social = torch.zeros(B, self.cfg.graph_dim, device=device)

        h_fused = self.fusion(h_text, h_visual, h_social)
        logits = self.classifier(h_fused)
        return logits

    # -- Introspection helpers, used by efficiency/compression scripts -- #
    def all_tt_linear_modules(self):
        return [m for m in self.modules() if isinstance(m, TTLinear)]

    def total_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters())

    def compression_report(self) -> dict:
        tt_modules = self.all_tt_linear_modules()
        tt_params = sum(m.num_parameters() for m in tt_modules)
        tt_dense_equiv = sum(m.out_features * m.in_features for m in tt_modules)
        other_params = self.total_parameters() - tt_params
        return {
            "total_params": self.total_parameters(),
            "tt_layer_params": tt_params,
            "tt_dense_equivalent": tt_dense_equiv,
            "non_tt_params": other_params,
            "num_tt_layers": len(tt_modules),
        }
