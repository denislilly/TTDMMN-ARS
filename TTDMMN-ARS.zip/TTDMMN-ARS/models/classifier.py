"""
TT-Linear Classification Head, Section 3.2 / 3.9.

Fully connected -> Softmax(binary: single-logit + sigmoid, per Eq. 1) ->
Cross entropy (Eq. 3). Implemented with a TT-compressed hidden layer
followed by a small dense output layer (dense, since the final
projection to 1-2 logits is tiny and gains nothing from TT compression).
"""

from __future__ import annotations

import torch
import torch.nn as nn

from models.tensor_train import TTLinear


class TTClassificationHead(nn.Module):
    """f(x; theta_TT) = sigma(g(...))  (Eq. 1). Binary veracity
    classification: outputs a single logit; apply `torch.sigmoid` (or
    let the loss function apply it, e.g. BCEWithLogitsLoss) to obtain
    y_hat in [0, 1]."""

    def __init__(
        self,
        in_dim: int = 256,
        hidden_dim: int = 128,
        num_classes: int = 2,
        tt_rank: int = 4,
        tt_order: int = 2,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.hidden = TTLinear(in_dim, hidden_dim, rank=tt_rank, order=tt_order)
        self.act = nn.GELU()
        self.dropout = nn.Dropout(dropout)
        # Binary case: single logit (sigmoid); multi-class: num_classes logits (softmax).
        self.num_classes = num_classes
        out_dim = 1 if num_classes == 2 else num_classes
        self.out = nn.Linear(hidden_dim, out_dim)

    def forward(self, h_fused: torch.Tensor) -> torch.Tensor:
        h = self.act(self.hidden(h_fused))
        h = self.dropout(h)
        logits = self.out(h)
        if self.num_classes == 2:
            return logits.squeeze(-1)  # (B,) raw logit for BCEWithLogitsLoss
        return logits  # (B, num_classes) raw logits for CrossEntropyLoss
