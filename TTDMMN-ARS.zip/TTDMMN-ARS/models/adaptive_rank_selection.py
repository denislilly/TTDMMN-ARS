"""
Adaptive Rank Selection (ARS), Section 3.8 of the manuscript.

ARS adds a nuclear-norm penalty to every TT core so that, during
training, the singular values of each core's matricisation are pushed
towards zero. Cores (or slices thereof) whose singular values fall
below a threshold after training can then be truncated, yielding a
network whose *effective* per-layer TT rank was learned automatically
rather than fixed a priori.

    Omega_rank(theta_TT) = sum_k || reshape(G_k, [r_{k-1} m_k, n_k r_k]) ||_*     (Eq. 12)

    lambda(t) = lambda_max * min(1, t / T_warmup)                                 (Eq. 13)

    L_total = L_CE + lambda(t) * Omega_rank(theta_TT)                             (Eq. 2)

After training, cores are truncated by zeroing singular values below
eps = 1e-3 (Section 3.8), yielding the final compact network.

This module is deliberately decoupled from any specific model: it
operates on any collection of `TTLinear` modules (see
`models/tensor_train.py`) discovered inside a parent `nn.Module`, so the
same ARS machinery is shared across the text (TCTE), visual (VFE), and
graph (GSPM) branches -- "coordinating rank reduction across the text,
visual, and graph branches within a unified training objective."
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple

import torch
import torch.nn as nn

from models.tensor_train import TTLinear


@dataclass
class ARSConfig:
    lambda_max: float = 1e-3
    warmup_steps: int = 1000
    truncation_eps: float = 1e-3
    min_rank: int = 1


def find_tt_linear_modules(model: nn.Module) -> Dict[str, TTLinear]:
    """Discover every TTLinear submodule in a model, keyed by its
    fully-qualified name (used so ARS can be applied jointly across
    heterogeneous text/vision/graph branches, per Section 3.8)."""
    found = {}
    for name, module in model.named_modules():
        if isinstance(module, TTLinear):
            found[name] = module
    return found


def rank_warmup_lambda(step: int, cfg: ARSConfig) -> float:
    """lambda(t) = lambda_max * min(1, t / T_warmup)   (Eq. 13)."""
    if cfg.warmup_steps <= 0:
        return cfg.lambda_max
    return cfg.lambda_max * min(1.0, step / cfg.warmup_steps)


def nuclear_norm_penalty(tt_modules: Iterable[TTLinear]) -> torch.Tensor:
    """Omega_rank(theta_TT) = sum_k ||reshape(G_k, ...)||_*   (Eq. 12).

    The nuclear norm of a matrix M is the sum of its singular values,
    i.e. the convex envelope of rank(M) on the unit operator-norm ball;
    penalising it drives the matricised TT cores towards low rank.
    """
    total = tt_modules_iter_penalty(tt_modules)
    return total


def tt_modules_iter_penalty(tt_modules: Iterable[TTLinear]) -> torch.Tensor:
    device = None
    total = None
    for layer in tt_modules:
        for mat in layer.core_reshape_for_nuclear_norm():
            # Nuclear norm via singular values; torch.linalg.svdvals is the
            # numerically stable way to obtain sigma_i(M) without forming U,V.
            sv = torch.linalg.svdvals(mat)
            term = sv.sum()
            if total is None:
                total = term
                device = term.device
            else:
                total = total + term
    if total is None:
        return torch.tensor(0.0)
    return total


class AdaptiveRankSelector:
    """
    Stateful ARS controller. Wraps a model's TT-Linear layers, exposes:
      - `penalty(step)`: the current lambda(t) * Omega_rank(theta_TT) term
         to be added to the training loss (Eq. 2).
      - `current_ranks()`: effective rank (number of singular values
         above `truncation_eps`) of each TT core, for monitoring/logging
         and for the rank-sensitivity experiments (r=2,4,8,16,Adaptive).
      - `truncate_(model)`: in-place hard truncation of near-zero
         singular directions after training, producing the final compact
         network described in Section 3.8.
    """

    def __init__(self, model: nn.Module, cfg: ARSConfig):
        self.cfg = cfg
        self.model = model
        self.tt_modules: Dict[str, TTLinear] = find_tt_linear_modules(model)

    def penalty(self, step: int) -> torch.Tensor:
        lam = rank_warmup_lambda(step, self.cfg)
        if lam == 0.0 or len(self.tt_modules) == 0:
            return torch.tensor(0.0)
        omega = nuclear_norm_penalty(self.tt_modules.values())
        return lam * omega

    @torch.no_grad()
    def current_ranks(self) -> Dict[str, List[int]]:
        """Effective rank per TT core (singular values > truncation_eps),
        used for logging / the rank-sensitivity study."""
        out: Dict[str, List[int]] = {}
        for name, layer in self.tt_modules.items():
            ranks = []
            for mat in layer.core_reshape_for_nuclear_norm():
                sv = torch.linalg.svdvals(mat)
                eff = int((sv > self.cfg.truncation_eps).sum().item())
                ranks.append(max(eff, self.cfg.min_rank))
            out[name] = ranks
        return out

    @torch.no_grad()
    def mean_post_truncation_rank(self) -> Tuple[float, float]:
        """Return (mean, std) of effective TT-rank across all discovered
        cores -- reported in Section 3.8 as "3.7 +/- 0.4" for BERT
        attention-layer cores after truncation."""
        all_ranks: List[int] = []
        for ranks in self.current_ranks().values():
            all_ranks.extend(ranks)
        if not all_ranks:
            return 0.0, 0.0
        t = torch.tensor(all_ranks, dtype=torch.float32)
        return t.mean().item(), t.std(unbiased=False).item()

    @torch.no_grad()
    def truncate_(self) -> None:
        """Hard-truncate each TT core's matricisation by zeroing singular
        directions with singular value below `truncation_eps`, then
        reproject back into core form. This is applied once after
        training completes (Section 3.8)."""
        for layer in self.tt_modules.values():
            new_cores = []
            for core in layer.cores:
                r0, mk, nk, r1 = core.shape
                mat = core.data.reshape(r0 * mk, nk * r1)
                U, S, Vh = torch.linalg.svd(mat, full_matrices=False)
                mask = S > self.cfg.truncation_eps
                if mask.sum().item() < self.cfg.min_rank:
                    # keep at least `min_rank` singular directions to avoid
                    # collapsing a layer to zero.
                    keep = min(self.cfg.min_rank, S.shape[0])
                    mask = torch.zeros_like(S, dtype=torch.bool)
                    mask[:keep] = True
                S_trunc = S * mask.float()
                mat_trunc = (U * S_trunc.unsqueeze(0)) @ Vh
                core.data.copy_(mat_trunc.reshape(r0, mk, nk, r1))
            layer.ranks = layer.ranks  # ranks metadata unchanged; only values truncated

    def rank_summary_table(self) -> List[Tuple[str, List[int]]]:
        """Convenience accessor for reporting/table generation scripts."""
        return list(self.current_ranks().items())
