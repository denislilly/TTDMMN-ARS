"""
Adaptive Cross-Modal Fusion Layer (ACFL), Section 3.7.

The three modality vectors (h_text, h_visual, h_social) are combined
through multi-head cross-modal attention. For the text-visual pair:

    CrossAttn(h_text, h_visual) = softmax(Q^T K / sqrt(d_k)) V         (Eq. 10)

with analogous operations computed for the text-social and
visual-social pairs. The fused representation

    H_fused = Concat(CrossAttn_tv, CrossAttn_ts, CrossAttn_vs) in R^384  (Eq. 11)

is projected to R^256 before the classification head.

This module additionally exposes the other fusion strategies requested
in the task specification (early fusion, late fusion, tensor fusion)
as selectable alternatives to ACFL, primarily for the ablation study
("Multimodal Fusion: Implement late fusion / early fusion / tensor
fusion / cross-modal attention according to the paper") -- the
manuscript's own default and best-performing configuration is
cross-modal attention (ACFL), which is what `TTDMMNARS` (in
ttdmmn_ars.py) uses unless configured otherwise.
"""

from __future__ import annotations

from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class CrossModalAttention(nn.Module):
    """Single-head scaled dot-product cross-attention between two
    modality vectors, each treated as a length-1 "sequence"
    (Eq. 10). Q comes from the first modality, K/V from the second.
    """

    def __init__(self, dim_q: int, dim_kv: int, dim_out: int, num_heads: int = 4):
        super().__init__()
        assert dim_out % num_heads == 0, "dim_out must be divisible by num_heads"
        self.num_heads = num_heads
        self.head_dim = dim_out // num_heads
        self.dim_out = dim_out

        self.q_proj = nn.Linear(dim_q, dim_out)
        self.k_proj = nn.Linear(dim_kv, dim_out)
        self.v_proj = nn.Linear(dim_kv, dim_out)
        self.out_proj = nn.Linear(dim_out, dim_out)

    def forward(self, x_q: torch.Tensor, x_kv: torch.Tensor) -> torch.Tensor:
        # x_q, x_kv: (B, dim). Treat as single-token sequences: (B, 1, dim)
        B = x_q.shape[0]
        Q = self.q_proj(x_q).view(B, 1, self.num_heads, self.head_dim).transpose(1, 2)  # (B,H,1,d)
        K = self.k_proj(x_kv).view(B, 1, self.num_heads, self.head_dim).transpose(1, 2)
        V = self.v_proj(x_kv).view(B, 1, self.num_heads, self.head_dim).transpose(1, 2)

        scores = (Q @ K.transpose(-2, -1)) / (self.head_dim ** 0.5)  # (B,H,1,1)  (Eq. 10)
        attn = F.softmax(scores, dim=-1)
        context = attn @ V  # (B,H,1,d)
        context = context.transpose(1, 2).contiguous().view(B, self.dim_out)
        return self.out_proj(context)


class AdaptiveCrossModalFusionLayer(nn.Module):
    """
    ACFL (Section 3.7): computes text<->visual, text<->social, and
    visual<->social cross-attention, concatenates the three results
    (Eq. 11: H_fused in R^384, 128 dims per pair by default), then
    projects to R^256 for the classification head.
    """

    def __init__(
        self,
        text_dim: int = 768,
        visual_dim: int = 512,
        social_dim: int = 256,
        pair_dim: int = 128,
        fused_out_dim: int = 256,
        num_heads: int = 4,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.tv_attn = CrossModalAttention(text_dim, visual_dim, pair_dim, num_heads)
        self.ts_attn = CrossModalAttention(text_dim, social_dim, pair_dim, num_heads)
        self.vs_attn = CrossModalAttention(visual_dim, social_dim, pair_dim, num_heads)

        self.proj = nn.Linear(pair_dim * 3, fused_out_dim)  # Eq. 11: 384 -> 256
        self.dropout = nn.Dropout(dropout)
        self.norm = nn.LayerNorm(fused_out_dim)

    def forward(self, h_text: torch.Tensor, h_visual: torch.Tensor, h_social: torch.Tensor) -> torch.Tensor:
        cross_tv = self.tv_attn(h_text, h_visual)
        cross_ts = self.ts_attn(h_text, h_social)
        cross_vs = self.vs_attn(h_visual, h_social)

        h_fused = torch.cat([cross_tv, cross_ts, cross_vs], dim=-1)  # Eq. 11, R^384
        h_fused = self.dropout(h_fused)
        out = self.proj(h_fused)  # -> R^256
        return self.norm(out)


class EarlyFusion(nn.Module):
    """Simple concatenation-then-projection fusion (ablation baseline)."""

    def __init__(self, text_dim: int, visual_dim: int, social_dim: int, out_dim: int = 256, dropout: float = 0.1):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Linear(text_dim + visual_dim + social_dim, out_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

    def forward(self, h_text, h_visual, h_social):
        return self.proj(torch.cat([h_text, h_visual, h_social], dim=-1))


class LateFusion(nn.Module):
    """Per-modality projection to a shared dim, then averaged
    (ablation baseline)."""

    def __init__(self, text_dim: int, visual_dim: int, social_dim: int, out_dim: int = 256, dropout: float = 0.1):
        super().__init__()
        self.text_proj = nn.Linear(text_dim, out_dim)
        self.visual_proj = nn.Linear(visual_dim, out_dim)
        self.social_proj = nn.Linear(social_dim, out_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, h_text, h_visual, h_social):
        t = self.text_proj(h_text)
        v = self.visual_proj(h_visual)
        s = self.social_proj(h_social)
        return self.dropout((t + v + s) / 3.0)


class TensorFusion(nn.Module):
    """
    Tensor Fusion Network style outer-product fusion (Zadeh et al. 2017,
    ref [41]), included as an ablation baseline. Computes the outer
    product of the (1-augmented) modality vectors and projects the
    (usually huge) result down to `out_dim` via a low-rank projection to
    keep parameter count tractable.
    """

    def __init__(
        self,
        text_dim: int,
        visual_dim: int,
        social_dim: int,
        out_dim: int = 256,
        proj_rank: int = 64,
        dropout: float = 0.1,
    ):
        super().__init__()
        # augmented dims (+1 for the bias/constant term, as in the TFN paper)
        self.dt, self.dv, self.ds = text_dim + 1, visual_dim + 1, social_dim + 1
        self.rank = proj_rank
        self.factor_t = nn.Parameter(torch.randn(self.dt, proj_rank) * 0.02)
        self.factor_v = nn.Parameter(torch.randn(self.dv, proj_rank) * 0.02)
        self.factor_s = nn.Parameter(torch.randn(self.ds, proj_rank) * 0.02)
        self.out_proj = nn.Linear(proj_rank, out_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, h_text, h_visual, h_social):
        B = h_text.shape[0]
        ones = torch.ones(B, 1, device=h_text.device, dtype=h_text.dtype)
        t = torch.cat([h_text, ones], dim=-1)
        v = torch.cat([h_visual, ones], dim=-1)
        s = torch.cat([h_social, ones], dim=-1)

        # Low-rank tensor fusion (Liu et al. 2018 factorisation trick):
        # avoids materialising the full (dt x dv x ds) outer product.
        ft = t @ self.factor_t   # (B, rank)
        fv = v @ self.factor_v
        fs = s @ self.factor_s
        fused = ft * fv * fs      # (B, rank) elementwise Hadamard product
        return self.dropout(self.out_proj(fused))


def build_fusion_layer(
    strategy: str,
    text_dim: int = 768,
    visual_dim: int = 512,
    social_dim: int = 256,
    out_dim: int = 256,
    dropout: float = 0.1,
) -> nn.Module:
    """Factory used by the ablation-study script to swap fusion strategies."""
    strategy = strategy.lower()
    if strategy in ("acfl", "cross_attention", "cross-modal-attention"):
        return AdaptiveCrossModalFusionLayer(
            text_dim=text_dim, visual_dim=visual_dim, social_dim=social_dim, fused_out_dim=out_dim, dropout=dropout
        )
    if strategy == "early":
        return EarlyFusion(text_dim, visual_dim, social_dim, out_dim, dropout)
    if strategy == "late":
        return LateFusion(text_dim, visual_dim, social_dim, out_dim, dropout)
    if strategy == "tensor":
        return TensorFusion(text_dim, visual_dim, social_dim, out_dim, dropout=dropout)
    raise ValueError(f"Unknown fusion strategy: {strategy}")
