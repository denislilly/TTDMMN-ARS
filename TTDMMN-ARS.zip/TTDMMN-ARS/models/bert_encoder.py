"""
TT-Compressed Text Encoder (TCTE), Section 3.4.

Wraps a HuggingFace `bert-base-uncased` model and replaces, in every one
of its 12 transformer layers, the four attention projections
(W_Q, W_K, W_V, W_O in R^{768x768}) and the two feed-forward matrices
(W_1 in R^{768x3072}, W_2 in R^{3072x768}) with TTLinear layers,
initialised via TT-SVD of the corresponding pretrained BERT weight
(Section 3.10). Standard scaled dot-product attention (Eq. 7) is
otherwise unchanged. The [CLS] embedding is used as the text
representation h_text in R^768.
"""

from __future__ import annotations

from typing import List, Optional

import torch
import torch.nn as nn

from models.tensor_train import TTLinear


def _replace_linear_with_tt(
    linear: nn.Linear, rank: int, order: int, init_from_pretrained: bool = True
) -> TTLinear:
    """Build a TTLinear that replaces an existing nn.Linear, optionally
    seeded from its pretrained dense weight via TT-SVD (Section 3.10)."""
    out_features, in_features = linear.weight.shape
    init_weight = linear.weight.data.clone() if init_from_pretrained else None
    tt = TTLinear(
        in_features=in_features,
        out_features=out_features,
        rank=rank,
        order=order,
        bias=linear.bias is not None,
        init_weight=init_weight,
    )
    if linear.bias is not None:
        with torch.no_grad():
            tt.bias.copy_(linear.bias.data)
    return tt


class TTCompressedTextEncoder(nn.Module):
    """BERT-Base encoder with TT-compressed attention/FFN projections.

    Args:
        pretrained_name: HuggingFace model id (default bert-base-uncased).
        tt_rank: uniform initial TT rank r for every replaced matrix
            (ARS subsequently learns per-layer effective ranks).
        tt_order: number of TT cores per matrix (d in Section 3.3; default 4).
        dropout: dropout applied to the pooled [CLS] embedding
            (Section 3.4 / 3.10: "Dropout p = 0.1 ... after each attention
            ... layer" -- attention/FFN internal dropout is inherited from
            the underlying BERT config; this extra dropout sits on the
            output representation before fusion).
        freeze_embeddings: if True, keep the (dense, non-TT) token/
            position/segment embedding tables frozen -- only the
            attention and FFN projections are TT-compressed and
            fine-tuned, matching the manuscript's focus on the
            attention/FFN sub-layers.
    """

    def __init__(
        self,
        pretrained_name: str = "bert-base-uncased",
        tt_rank: int = 4,
        tt_order: int = 4,
        dropout: float = 0.1,
        freeze_embeddings: bool = False,
        init_from_pretrained: bool = True,
    ):
        super().__init__()
        from transformers import BertModel, BertConfig

        if init_from_pretrained:
            self.bert = BertModel.from_pretrained(pretrained_name)
        else:
            config = BertConfig.from_pretrained(pretrained_name)
            self.bert = BertModel(config)

        self.hidden_size = self.bert.config.hidden_size
        self.dropout = nn.Dropout(dropout)

        self._tt_compress(tt_rank, tt_order, init_from_pretrained)

        if freeze_embeddings:
            for p in self.bert.embeddings.parameters():
                p.requires_grad = False

    def _tt_compress(self, tt_rank: int, tt_order: int, init_from_pretrained: bool) -> None:
        """Replace W_Q, W_K, W_V, W_O and the two FFN matrices in every
        BERT layer with TTLinear (Section 3.4)."""
        for layer in self.bert.encoder.layer:
            attn = layer.attention
            self_attn = attn.self
            self_attn.query = _replace_linear_with_tt(self_attn.query, tt_rank, tt_order, init_from_pretrained)
            self_attn.key = _replace_linear_with_tt(self_attn.key, tt_rank, tt_order, init_from_pretrained)
            self_attn.value = _replace_linear_with_tt(self_attn.value, tt_rank, tt_order, init_from_pretrained)
            attn.output.dense = _replace_linear_with_tt(attn.output.dense, tt_rank, tt_order, init_from_pretrained)

            layer.intermediate.dense = _replace_linear_with_tt(
                layer.intermediate.dense, tt_rank, tt_order, init_from_pretrained
            )
            layer.output.dense = _replace_linear_with_tt(
                layer.output.dense, tt_rank, tt_order, init_from_pretrained
            )

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        token_type_ids: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Returns h_text in R^{batch, 768} (the [CLS] embedding)."""
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids,
        )
        cls = outputs.last_hidden_state[:, 0, :]  # [CLS] token
        return self.dropout(cls)

    def tt_linear_modules(self) -> List[TTLinear]:
        return [m for m in self.modules() if isinstance(m, TTLinear)]

    def compression_summary(self) -> dict:
        modules = self.tt_linear_modules()
        tt_params = sum(m.num_parameters() for m in modules)
        dense_params = sum(m.out_features * m.in_features for m in modules)
        return {
            "num_tt_layers": len(modules),
            "tt_params": tt_params,
            "dense_equivalent_params": dense_params,
            "compression_ratio": dense_params / max(tt_params, 1),
        }
