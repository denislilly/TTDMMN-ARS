"""Reproducibility utilities (Section: "Reproducibility" in the task
spec) -- random seed fixing, CUDA determinism, config snapshotting."""

from __future__ import annotations

import json
import os
import random
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch


def set_seed(seed: int = 42, deterministic_cuda: bool = True) -> None:
    """Fix all relevant RNG seeds. If `deterministic_cuda`, also request
    deterministic CUDA algorithms (may reduce throughput but improves
    exact reproducibility across runs/hardware)."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)

    if deterministic_cuda:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        try:
            torch.use_deterministic_algorithms(True, warn_only=True)
        except TypeError:
            torch.use_deterministic_algorithms(True)
    else:
        torch.backends.cudnn.benchmark = True


def save_config(cfg: Any, path: str) -> None:
    """Snapshot a (dataclass or dict) config alongside checkpoints/logs
    so every run's exact hyperparameters are recoverable."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    data = asdict(cfg) if is_dataclass(cfg) else dict(cfg)
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=str)


def load_config_json(path: str) -> dict:
    with open(path) as f:
        return json.load(f)


def worker_init_fn(worker_id: int) -> None:
    """Pass to DataLoader(worker_init_fn=...) so DataLoader worker
    processes get distinct-but-reproducible seeds."""
    seed = torch.initial_seed() % (2**32)
    np.random.seed(seed + worker_id)
    random.seed(seed + worker_id)
