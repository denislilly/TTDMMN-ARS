"""Logging utilities -- console + file logging, TensorBoard, and
optional Weights & Biases tracking (Section: "automatic experiment
tracking / TensorBoard / Weights & Biases (optional)")."""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any, Dict, Optional


def get_logger(name: str, log_file: Optional[str] = None, level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.propagate = False
    if logger.handlers:
        return logger  # avoid duplicate handlers on repeated calls

    fmt = logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s", "%Y-%m-%d %H:%M:%S")

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(fmt)
    logger.addHandler(stream_handler)

    if log_file:
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(fmt)
        logger.addHandler(file_handler)

    return logger


class ExperimentTracker:
    """Thin wrapper unifying TensorBoard and (optional) Weights & Biases
    logging behind one interface, so trainers/experiment scripts don't
    need to special-case either backend."""

    def __init__(
        self,
        log_dir: str,
        use_tensorboard: bool = True,
        use_wandb: bool = False,
        wandb_project: Optional[str] = None,
        run_name: Optional[str] = None,
        config: Optional[Dict[str, Any]] = None,
    ):
        self.use_tensorboard = use_tensorboard
        self.use_wandb = use_wandb
        self._tb = None
        self._wandb = None

        if use_tensorboard:
            from torch.utils.tensorboard import SummaryWriter

            Path(log_dir).mkdir(parents=True, exist_ok=True)
            self._tb = SummaryWriter(log_dir=log_dir)

        if use_wandb:
            try:
                import wandb

                wandb.init(project=wandb_project or "ttdmmn-ars", name=run_name, config=config)
                self._wandb = wandb
            except ImportError:
                logging.getLogger(__name__).warning(
                    "wandb requested but not installed; continuing without W&B logging. "
                    "Install with `pip install wandb` to enable."
                )
                self.use_wandb = False

    def log_scalars(self, scalars: Dict[str, float], step: int) -> None:
        if self._tb is not None:
            for k, v in scalars.items():
                self._tb.add_scalar(k, v, step)
        if self.use_wandb and self._wandb is not None:
            self._wandb.log(scalars, step=step)

    def log_figure(self, tag: str, figure, step: int) -> None:
        if self._tb is not None:
            self._tb.add_figure(tag, figure, step)
        if self.use_wandb and self._wandb is not None:
            self._wandb.log({tag: self._wandb.Image(figure)}, step=step)

    def close(self) -> None:
        if self._tb is not None:
            self._tb.close()
        if self.use_wandb and self._wandb is not None:
            self._wandb.finish()
