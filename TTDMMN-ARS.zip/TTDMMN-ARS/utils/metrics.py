"""
Evaluation metrics, Section 3.9 (Eq. 14-22).

    Acc = (TP+TN) / (TP+TN+FP+FN)                       (Eq. 14)
    P = TP/(TP+FP), R = TP/(TP+FN)                        (Eq. 15)
    F1 = 2PR/(P+R), Macro-F1 = (1/C) sum_c F1_c           (Eq. 16)
    AUC-ROC                                                (Eq. 17)
    MCC (Matthews Correlation Coefficient)                 (Eq. 18)
    Cohen's Kappa: kappa = (p0 - pe) / (1 - pe)             (Eq. 19)
    Compression ratio: CR = P_full / P_TT                   (Eq. 20)
    Inference speedup: S = T_dense / T_TT                    (Eq. 21)
    Memory reduction: MR = 1 - M_TT / M_dense                 (Eq. 22)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Sequence

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    roc_auc_score,
    matthews_corrcoef,
    cohen_kappa_score,
    confusion_matrix,
    precision_recall_curve,
    roc_curve,
)


@dataclass
class ClassificationMetrics:
    accuracy: float
    precision: float
    recall: float
    f1: float
    macro_f1: float
    auc_roc: Optional[float]
    mcc: float
    kappa: float
    confusion: np.ndarray

    def as_dict(self) -> Dict[str, float]:
        d = {
            "accuracy": self.accuracy,
            "precision": self.precision,
            "recall": self.recall,
            "f1": self.f1,
            "macro_f1": self.macro_f1,
            "mcc": self.mcc,
            "kappa": self.kappa,
        }
        if self.auc_roc is not None:
            d["auc_roc"] = self.auc_roc
        return d


def compute_classification_metrics(
    y_true: Sequence[int],
    y_pred: Sequence[int],
    y_prob: Optional[Sequence[float]] = None,
) -> ClassificationMetrics:
    """Computes Eq. 14-19 for binary classification.

    Args:
        y_true: ground-truth labels (0/1).
        y_pred: predicted hard labels (0/1).
        y_prob: predicted probability of the positive class, required
            for AUC-ROC (Eq. 17); if omitted, auc_roc is None.
    """
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    acc = accuracy_score(y_true, y_pred)  # Eq. 14
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average="binary", zero_division=0
    )  # Eq. 15-16
    _, _, macro_f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average="macro", zero_division=0
    )  # Eq. 16
    mcc = matthews_corrcoef(y_true, y_pred)  # Eq. 18
    kappa = cohen_kappa_score(y_true, y_pred)  # Eq. 19
    cm = confusion_matrix(y_true, y_pred)

    auc = None
    if y_prob is not None and len(np.unique(y_true)) > 1:
        auc = roc_auc_score(y_true, y_prob)  # Eq. 17

    return ClassificationMetrics(
        accuracy=float(acc),
        precision=float(precision),
        recall=float(recall),
        f1=float(f1),
        macro_f1=float(macro_f1),
        auc_roc=float(auc) if auc is not None else None,
        mcc=float(mcc),
        kappa=float(kappa),
        confusion=cm,
    )


def roc_curve_points(y_true: Sequence[int], y_prob: Sequence[float]):
    """Returns (fpr, tpr, thresholds) for ROC-curve plotting (Figure 3)."""
    return roc_curve(y_true, y_prob)


def pr_curve_points(y_true: Sequence[int], y_prob: Sequence[float]):
    """Returns (precision, recall, thresholds) for PR-curve plotting."""
    return precision_recall_curve(y_true, y_prob)


# --------------------------------------------------------------------------- #
# Efficiency metrics (Table 3, Eq. 20-22)
# --------------------------------------------------------------------------- #
def compression_ratio(params_full: int, params_tt: int) -> float:
    """CR = P_full / P_TT   (Eq. 20)."""
    return params_full / max(params_tt, 1)


def inference_speedup(latency_dense_ms: float, latency_tt_ms: float) -> float:
    """S = T_dense / T_TT   (Eq. 21)."""
    return latency_dense_ms / max(latency_tt_ms, 1e-9)


def memory_reduction(mem_tt_gb: float, mem_dense_gb: float) -> float:
    """MR = 1 - M_TT / M_dense   (Eq. 22)."""
    return 1.0 - (mem_tt_gb / max(mem_dense_gb, 1e-9))


def summarize_cross_validation(fold_metrics: Sequence[Dict[str, float]]) -> Dict[str, Dict[str, float]]:
    """Given a list of per-fold metric dicts (e.g. from 5-fold CV), return
    {metric_name: {"mean": ..., "std": ...}} -- used to report the
    manuscript's "X.XX +/- Y.YY%" figures (e.g. Macro-F1 97.58 +/- 0.31%
    on WELFake)."""
    keys = fold_metrics[0].keys()
    out = {}
    for k in keys:
        vals = np.array([fm[k] for fm in fold_metrics if k in fm])
        out[k] = {"mean": float(vals.mean()), "std": float(vals.std(ddof=0))}
    return out
