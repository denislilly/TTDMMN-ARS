"""
Config loader supporting a minimal `defaults: [other.yaml]` inheritance
convention (à la Hydra) used across configs/*.yaml, so per-dataset
configs only need to specify what differs from configs/default.yaml.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

import yaml


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(base)
    for k, v in override.items():
        if k == "defaults":
            continue
        if isinstance(v, dict) and isinstance(merged.get(k), dict):
            merged[k] = _deep_merge(merged[k], v)
        else:
            merged[k] = v
    return merged


def load_config(path: str) -> Dict[str, Any]:
    """Load a YAML config, recursively resolving `defaults: [file, ...]`
    relative to the same directory as `path`, then deep-merging the
    current file's keys on top."""
    path = Path(path)
    with open(path) as f:
        cfg = yaml.safe_load(f) or {}

    merged: Dict[str, Any] = {}
    for dep in cfg.get("defaults", []):
        dep_path = path.parent / dep
        merged = _deep_merge(merged, load_config(str(dep_path)))

    return _deep_merge(merged, cfg)
