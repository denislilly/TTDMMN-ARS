"""
Training objective, Section 3.1 / 3.10.

    L_total = L_CE + lambda(t) * Omega_rank(theta_TT)                  (Eq. 2)
    L_CE    = -[y*log(y_hat) + (1-y)*log(1-y_hat)]                     (Eq. 3)

Section 3.10: "Focal loss (gamma = 2) is used for the
FakeNewsNet-GossipCop split to handle the 76/24 class imbalance."
"""

from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


class BinaryCrossEntropyLoss(nn.Module):
    """L_CE, Eq. 3, computed from raw logits via BCEWithLogitsLoss for
    numerical stability (mathematically identical to Eq. 3 once y_hat =
    sigmoid(logit))."""

    def __init__(self, pos_weight: Optional[float] = None):
        super().__init__()
        pw = torch.tensor(pos_weight) if pos_weight is not None else None
        self.register_buffer("pos_weight", pw, persistent=False)

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        return F.binary_cross_entropy_with_logits(
            logits, targets.float(), pos_weight=self.pos_weight
        )


class FocalLoss(nn.Module):
    """Binary focal loss (Lin et al. 2017), gamma=2 per Section 3.10, used
    for the FakeNewsNet-GossipCop split to handle its 76/24 class
    imbalance.

        FL(p_t) = -alpha_t * (1 - p_t)^gamma * log(p_t)
    """

    def __init__(self, gamma: float = 2.0, alpha: float = 0.25):
        super().__init__()
        self.gamma = gamma
        self.alpha = alpha

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        targets = targets.float()
        p = torch.sigmoid(logits)
        ce = F.binary_cross_entropy_with_logits(logits, targets, reduction="none")
        p_t = p * targets + (1 - p) * (1 - targets)
        alpha_t = self.alpha * targets + (1 - self.alpha) * (1 - targets)
        loss = alpha_t * (1 - p_t).pow(self.gamma) * ce
        return loss.mean()


class TTDMMNARSLoss(nn.Module):
    """
    Full training objective, Eq. 2: classification loss plus the
    warmed-up nuclear-norm rank-regularisation penalty produced by the
    `AdaptiveRankSelector` (see models/adaptive_rank_selection.py).

    Usage:
        loss_fn = TTDMMNARSLoss(use_focal=(dataset == "gossipcop"))
        ars = AdaptiveRankSelector(model, ARSConfig(...))
        ...
        logits = model(batch)
        loss, logs = loss_fn(logits, targets, rank_penalty=ars.penalty(step))
    """

    def __init__(
        self,
        use_focal: bool = False,
        focal_gamma: float = 2.0,
        focal_alpha: float = 0.25,
        pos_weight: Optional[float] = None,
    ):
        super().__init__()
        if use_focal:
            self.cls_loss = FocalLoss(gamma=focal_gamma, alpha=focal_alpha)
        else:
            self.cls_loss = BinaryCrossEntropyLoss(pos_weight=pos_weight)

    def forward(self, logits: torch.Tensor, targets: torch.Tensor, rank_penalty: torch.Tensor):
        ce = self.cls_loss(logits, targets)
        rank_penalty = rank_penalty.to(ce.device) if rank_penalty.numel() else rank_penalty
        total = ce + rank_penalty
        logs = {
            "loss_total": total.item(),
            "loss_ce": ce.item(),
            "loss_rank": float(rank_penalty.detach()),
        }
        return total, logs
