import math

import torch

from models.tensor_train import (
    factorize_dims,
    tt_svd,
    reconstruct_from_cores,
    tt_parameter_count,
    compression_ratio,
    TTLinear,
)


def test_factorize_dims_product_matches():
    mf, nf = factorize_dims(768, 768, order=4)
    assert math.prod(mf) == 768
    assert math.prod(nf) == 768
    assert len(mf) == 4 and len(nf) == 4


def test_tt_svd_reconstruction_near_exact_at_full_rank():
    torch.manual_seed(0)
    mf, nf = [2, 2, 2, 2], [2, 2, 2, 2]
    W = torch.randn(16, 16).double()
    ranks = [16, 16, 16]  # generous relative to true max ranks at this size
    cores = tt_svd(W, mf, nf, ranks)
    W_rec = reconstruct_from_cores(cores)
    rel_err = (W - W_rec).norm() / W.norm()
    assert rel_err < 1e-10


def test_tt_svd_low_rank_is_lossy_but_bounded():
    torch.manual_seed(0)
    mf, nf = factorize_dims(768, 768, order=4)
    W = torch.randn(768, 768).double()
    cores = tt_svd(W, mf, nf, [4, 4, 4])
    W_rec = reconstruct_from_cores(cores)
    rel_err = (W - W_rec).norm() / W.norm()
    assert 0.0 < rel_err.item() <= 1.5  # lossy compression, but finite/stable


def test_ttlinear_forward_backward_shapes():
    torch.manual_seed(0)
    layer = TTLinear(in_features=128, out_features=256, rank=4, order=3)
    x = torch.randn(5, 7, 128, requires_grad=True)
    y = layer(x)
    assert y.shape == (5, 7, 256)
    y.sum().backward()
    assert layer.cores[0].grad is not None


def test_ttlinear_compression_ratio_beats_dense():
    layer = TTLinear(in_features=768, out_features=768, rank=4, order=4)
    dense_params = 768 * 768
    assert layer.num_parameters() < dense_params
    assert layer.compression_ratio() > 1.0


def test_tt_parameter_count_matches_manual_sum():
    mf, nf = [4, 6, 4, 8], [4, 6, 4, 8]
    ranks = [4, 4, 4]
    full_ranks = [1] + ranks + [1]
    expected = sum(
        full_ranks[k] * mf[k] * nf[k] * full_ranks[k + 1] for k in range(len(mf))
    )
    assert tt_parameter_count(mf, nf, ranks) == expected


def test_ttlinear_svd_init_from_pretrained_weight():
    torch.manual_seed(0)
    W = torch.randn(64, 64)
    layer = TTLinear(64, 64, rank=8, order=2, init_weight=W, init_noise_std=0.0)
    W_rec = layer.dense_weight()
    # rank=8 on a 64x64 (order=2) matrix is a real (lossy) truncation, not a
    # generous rank -- this asserts SVD-init runs and produces a finite,
    # non-trivial approximation (not that it's near-exact; see the
    # near-exact recovery test above for the "generous rank" case).
    rel_err = (W - W_rec).norm() / W.norm()
    assert torch.isfinite(rel_err)
    assert 0.0 < rel_err.item() < 1.0
