import torch
import torch.nn as nn

from models.tensor_train import TTLinear
from models.adaptive_rank_selection import (
    AdaptiveRankSelector,
    ARSConfig,
    rank_warmup_lambda,
    find_tt_linear_modules,
)


class _ToyMultiBranch(nn.Module):
    def __init__(self):
        super().__init__()
        self.text_proj = TTLinear(32, 32, rank=8, order=2)
        self.visual_proj = TTLinear(32, 32, rank=8, order=2)
        self.plain = nn.Linear(32, 32)  # should NOT be discovered by ARS

    def forward(self, x):
        return self.visual_proj(self.text_proj(self.plain(x)))


def test_find_tt_linear_modules_discovers_all_branches_only():
    model = _ToyMultiBranch()
    found = find_tt_linear_modules(model)
    assert set(found.keys()) == {"text_proj", "visual_proj"}


def test_rank_warmup_lambda_schedule():
    cfg = ARSConfig(lambda_max=1.0, warmup_steps=100)
    assert rank_warmup_lambda(0, cfg) == 0.0
    assert abs(rank_warmup_lambda(50, cfg) - 0.5) < 1e-9
    assert rank_warmup_lambda(100, cfg) == 1.0
    assert rank_warmup_lambda(500, cfg) == 1.0  # clamped at lambda_max


def test_penalty_is_nonnegative_and_requires_grad():
    model = _ToyMultiBranch()
    cfg = ARSConfig(lambda_max=0.01, warmup_steps=10)
    ars = AdaptiveRankSelector(model, cfg)
    penalty = ars.penalty(5)
    assert penalty.item() >= 0.0
    assert penalty.requires_grad


def test_truncate_preserves_shapes():
    model = _ToyMultiBranch()
    cfg = ARSConfig(truncation_eps=1e6, min_rank=1)  # aggressive truncation
    ars = AdaptiveRankSelector(model, cfg)
    shapes_before = [c.shape for c in model.text_proj.cores]
    ars.truncate_()
    shapes_after = [c.shape for c in model.text_proj.cores]
    assert shapes_before == shapes_after  # truncation zeroes values, not shapes
