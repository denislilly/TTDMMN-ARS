import torch

from models.multimodal_fusion import build_fusion_layer
from models.graph_encoder import GraphSocialPropagationModule
from models.vit_encoder import VisualFeatureExtractor, TuckerConv2d
from models.classifier import TTClassificationHead


def test_all_fusion_strategies_produce_correct_shape_and_gradients():
    torch.manual_seed(0)
    B = 4
    h_text, h_visual, h_social = torch.randn(B, 768), torch.randn(B, 512), torch.randn(B, 256)
    for strategy in ["acfl", "early", "late", "tensor"]:
        layer = build_fusion_layer(strategy, 768, 512, 256, out_dim=256)
        out = layer(h_text, h_visual, h_social)
        assert out.shape == (B, 256)
        out.sum().backward()


def test_graph_module_zero_placeholder_degrades_gracefully():
    gspm = GraphSocialPropagationModule(in_features=16, hidden_features=32, out_features=64, backbone="gcn")
    zero = gspm.zero_placeholder(batch_size=3, device=torch.device("cpu"))
    assert zero.shape == (3, 64)
    assert torch.all(zero == 0)


def test_tucker_conv_reduces_parameters_vs_dense():
    conv = TuckerConv2d(64, 128, kernel_size=3, rank_ratio=0.5)
    dense_equiv = conv.dense_equivalent_params()
    assert conv.num_parameters() < dense_equiv
    assert conv.compression_ratio() > 1.0


def test_visual_extractor_forward_shape_no_pretrained():
    torch.manual_seed(0)
    vfe = VisualFeatureExtractor(pretrained=False, rank_ratio=0.5, tt_rank=4, tt_order=3, out_dim=512)
    imgs = torch.randn(2, 3, 224, 224)
    out = vfe(imgs)
    assert out.shape == (2, 512)


def test_classification_head_binary_output_shape():
    head = TTClassificationHead(in_dim=256, hidden_dim=64, num_classes=2, tt_rank=4, tt_order=2)
    x = torch.randn(6, 256)
    logits = head(x)
    assert logits.shape == (6,)
