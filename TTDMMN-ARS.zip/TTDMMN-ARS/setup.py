from pathlib import Path

from setuptools import find_packages, setup

this_dir = Path(__file__).parent
requirements = (this_dir / "requirements.txt").read_text().splitlines()
requirements = [r.strip() for r in requirements if r.strip() and not r.startswith("#")]

setup(
    name="ttdmmn-ars",
    version="1.0.0",
    description=(
        "Tensor Train Decomposed Multi-Modal Neural Network with Adaptive "
        "Rank Selection (TTDMMN-ARS) for Efficient Fake News Detection"
    ),
    long_description=(this_dir / "README.md").read_text(errors="ignore"),
    long_description_content_type="text/markdown",
    author="TTDMMN-ARS Authors",
    license="MIT",
    packages=find_packages(exclude=["tests", "notebooks", "outputs*"]),
    python_requires=">=3.11",
    install_requires=requirements,
    classifiers=[
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
