"""
Trainer, Section 3.10 ("Training Details").

    Optimiser: AdamW (beta1=0.9, beta2=0.999, weight_decay=1e-2)
    LR schedule: cosine from eta_max=2e-5 to eta_min=1e-7 over 10 epochs,
                 with a 500-step linear warm-up.
    Batch size: 32, with 4-step gradient accumulation (effective 128).
    Dropout: p=0.1 after each attention and GCN layer.
    Early stopping: patience 3, monitoring validation Macro-F1.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, Optional

import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.utils.data import DataLoader

from models.adaptive_rank_selection import AdaptiveRankSelector, ARSConfig
from losses.classification_loss import TTDMMNARSLoss
from utils.logger import get_logger, ExperimentTracker
from utils.metrics import compute_classification_metrics


@dataclass
class TrainerConfig:
    lr_max: float = 2e-5
    lr_min: float = 1e-7
    weight_decay: float = 1e-2
    adam_beta1: float = 0.9
    adam_beta2: float = 0.999
    num_epochs: int = 10
    warmup_steps: int = 500
    grad_accum_steps: int = 4
    batch_size: int = 32
    max_grad_norm: float = 1.0
    early_stopping_patience: int = 3
    use_focal_loss: bool = False
    focal_gamma: float = 2.0
    focal_alpha: float = 0.25

    # ARS
    ars_lambda_max: float = 1e-3
    ars_warmup_steps: int = 1000
    ars_truncation_eps: float = 1e-3

    checkpoint_dir: str = "outputs/checkpoints"
    log_dir: str = "outputs/logs"
    run_name: str = "ttdmmn_ars_run"
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    use_tensorboard: bool = True
    use_wandb: bool = False
    log_every_n_steps: int = 50


def cosine_schedule_with_warmup(step: int, total_steps: int, warmup_steps: int, lr_max: float, lr_min: float) -> float:
    """Linear warm-up for `warmup_steps`, then cosine decay from lr_max
    to lr_min over the remaining steps (Section 3.10)."""
    if step < warmup_steps:
        return lr_max * (step + 1) / max(warmup_steps, 1)
    progress = (step - warmup_steps) / max(total_steps - warmup_steps, 1)
    progress = min(max(progress, 0.0), 1.0)
    cosine = 0.5 * (1 + math.cos(math.pi * progress))
    return lr_min + (lr_max - lr_min) * cosine


class Trainer:
    def __init__(
        self,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: DataLoader,
        cfg: TrainerConfig,
        batch_to_model_inputs: Callable[[dict, str], dict],
        batch_to_targets: Callable[[dict, str], torch.Tensor],
    ):
        """
        Args:
            batch_to_model_inputs(batch, device) -> kwargs dict for model.forward()
            batch_to_targets(batch, device) -> (B,) target tensor
            (kept as injected callables so the Trainer is dataset-agnostic
            across WELFake / LIAR / FakeNewsNet / COVID-19 loaders.)
        """
        self.model = model.to(cfg.device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.cfg = cfg
        self.batch_to_model_inputs = batch_to_model_inputs
        self.batch_to_targets = batch_to_targets

        self.optimizer = AdamW(
            self.model.parameters(),
            lr=cfg.lr_max,
            betas=(cfg.adam_beta1, cfg.adam_beta2),
            weight_decay=cfg.weight_decay,
        )
        self.loss_fn = TTDMMNARSLoss(
            use_focal=cfg.use_focal_loss, focal_gamma=cfg.focal_gamma, focal_alpha=cfg.focal_alpha
        )
        self.ars = AdaptiveRankSelector(
            self.model,
            ARSConfig(
                lambda_max=cfg.ars_lambda_max,
                warmup_steps=cfg.ars_warmup_steps,
                truncation_eps=cfg.ars_truncation_eps,
            ),
        )

        steps_per_epoch = math.ceil(len(train_loader) / cfg.grad_accum_steps)
        self.total_steps = steps_per_epoch * cfg.num_epochs

        self.logger = get_logger(cfg.run_name, log_file=str(Path(cfg.log_dir) / f"{cfg.run_name}.log"))
        self.tracker = ExperimentTracker(
            log_dir=str(Path(cfg.log_dir) / cfg.run_name),
            use_tensorboard=cfg.use_tensorboard,
            use_wandb=cfg.use_wandb,
            run_name=cfg.run_name,
        )

        self.global_step = 0
        self.best_macro_f1 = -1.0
        self.epochs_without_improvement = 0

    def _set_lr(self, step: int) -> float:
        lr = cosine_schedule_with_warmup(step, self.total_steps, self.cfg.warmup_steps, self.cfg.lr_max, self.cfg.lr_min)
        for group in self.optimizer.param_groups:
            group["lr"] = lr
        return lr

    def train(self) -> Dict[str, float]:
        for epoch in range(self.cfg.num_epochs):
            self._train_one_epoch(epoch)
            val_metrics = self.evaluate(self.val_loader)
            self.logger.info(f"[epoch {epoch}] val: {val_metrics}")
            self.tracker.log_scalars({f"val/{k}": v for k, v in val_metrics.items()}, self.global_step)

            improved = val_metrics["macro_f1"] > self.best_macro_f1
            if improved:
                self.best_macro_f1 = val_metrics["macro_f1"]
                self.epochs_without_improvement = 0
                self.save_checkpoint(tag="best")
            else:
                self.epochs_without_improvement += 1

            self.save_checkpoint(tag="last")

            if self.epochs_without_improvement >= self.cfg.early_stopping_patience:
                self.logger.info(
                    f"Early stopping at epoch {epoch}: no val Macro-F1 improvement for "
                    f"{self.cfg.early_stopping_patience} epochs."
                )
                break

        # Post-training ARS rank truncation (Section 3.8)
        self.ars.truncate_()
        mean_rank, std_rank = self.ars.mean_post_truncation_rank()
        self.logger.info(f"Post-truncation TT-rank: {mean_rank:.2f} +/- {std_rank:.2f}")
        self.save_checkpoint(tag="final_truncated")

        self.tracker.close()
        return {"best_val_macro_f1": self.best_macro_f1, "post_truncation_mean_rank": mean_rank}

    def _train_one_epoch(self, epoch: int) -> None:
        self.model.train()
        self.optimizer.zero_grad()
        t0 = time.time()

        for i, batch in enumerate(self.train_loader):
            inputs = self.batch_to_model_inputs(batch, self.cfg.device)
            targets = self.batch_to_targets(batch, self.cfg.device)

            logits = self.model(**inputs)
            rank_penalty = self.ars.penalty(self.global_step)
            loss, logs = self.loss_fn(logits, targets, rank_penalty)
            (loss / self.cfg.grad_accum_steps).backward()

            if (i + 1) % self.cfg.grad_accum_steps == 0:
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.max_grad_norm)
                lr = self._set_lr(self.global_step)
                self.optimizer.step()
                self.optimizer.zero_grad()
                self.global_step += 1

                if self.global_step % self.cfg.log_every_n_steps == 0:
                    elapsed = time.time() - t0
                    self.logger.info(
                        f"epoch {epoch} step {self.global_step}/{self.total_steps} "
                        f"loss={logs['loss_total']:.4f} ce={logs['loss_ce']:.4f} "
                        f"rank_pen={logs['loss_rank']:.6f} lr={lr:.2e} ({elapsed:.1f}s)"
                    )
                    self.tracker.log_scalars({f"train/{k}": v for k, v in logs.items()}, self.global_step)
                    self.tracker.log_scalars({"train/lr": lr}, self.global_step)

    @torch.no_grad()
    def evaluate(self, loader: DataLoader) -> Dict[str, float]:
        self.model.eval()
        all_true, all_pred, all_prob = [], [], []
        for batch in loader:
            inputs = self.batch_to_model_inputs(batch, self.cfg.device)
            targets = self.batch_to_targets(batch, self.cfg.device)
            logits = self.model(**inputs)
            prob = torch.sigmoid(logits)
            pred = (prob > 0.5).long()

            all_true.extend(targets.cpu().tolist())
            all_pred.extend(pred.cpu().tolist())
            all_prob.extend(prob.cpu().tolist())

        metrics = compute_classification_metrics(all_true, all_pred, all_prob)
        return metrics.as_dict()

    def save_checkpoint(self, tag: str = "last") -> str:
        ckpt_dir = Path(self.cfg.checkpoint_dir) / self.cfg.run_name
        ckpt_dir.mkdir(parents=True, exist_ok=True)
        path = ckpt_dir / f"{tag}.pt"
        torch.save(
            {
                "model_state_dict": self.model.state_dict(),
                "optimizer_state_dict": self.optimizer.state_dict(),
                "global_step": self.global_step,
                "best_macro_f1": self.best_macro_f1,
                "cfg": self.cfg,
            },
            path,
        )
        return str(path)

    def load_checkpoint(self, path: str, resume_optimizer: bool = True) -> None:
        ckpt = torch.load(path, map_location=self.cfg.device)
        self.model.load_state_dict(ckpt["model_state_dict"])
        if resume_optimizer and "optimizer_state_dict" in ckpt:
            self.optimizer.load_state_dict(ckpt["optimizer_state_dict"])
        self.global_step = ckpt.get("global_step", 0)
        self.best_macro_f1 = ckpt.get("best_macro_f1", -1.0)
        self.logger.info(f"Resumed from {path} at step {self.global_step}")
