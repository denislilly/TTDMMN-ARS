"""
Evaluator, Section 3.9 / "Cross Validation" experiment.

Provides:
  - `evaluate_model`: run a trained model over a DataLoader and compute
    the full metric suite (Eq. 14-19).
  - `k_fold_cross_validate`: fit-and-evaluate a fresh model across k
    folds of a dataset, returning per-fold metrics plus mean +/- std
    (Section "Cross Validation: Five-fold / Mean / Standard deviation").
"""

from __future__ import annotations

from typing import Callable, Dict, List

import torch
from torch.utils.data import DataLoader, Dataset, Subset
from sklearn.model_selection import StratifiedKFold

from utils.metrics import compute_classification_metrics, summarize_cross_validation


@torch.no_grad()
def evaluate_model(
    model: torch.nn.Module,
    loader: DataLoader,
    batch_to_model_inputs: Callable,
    batch_to_targets: Callable,
    device: str = "cuda" if torch.cuda.is_available() else "cpu",
) -> Dict[str, float]:
    model.eval()
    model.to(device)
    all_true, all_pred, all_prob = [], [], []
    for batch in loader:
        inputs = batch_to_model_inputs(batch, device)
        targets = batch_to_targets(batch, device)
        logits = model(**inputs)
        prob = torch.sigmoid(logits)
        pred = (prob > 0.5).long()
        all_true.extend(targets.cpu().tolist())
        all_pred.extend(pred.cpu().tolist())
        all_prob.extend(prob.cpu().tolist())
    return compute_classification_metrics(all_true, all_pred, all_prob).as_dict()


def k_fold_cross_validate(
    dataset: Dataset,
    labels: List[int],
    build_model_fn: Callable[[], torch.nn.Module],
    build_trainer_fn: Callable[[torch.nn.Module, DataLoader, DataLoader], "Trainer"],  # noqa: F821
    batch_size: int = 32,
    k: int = 5,
    seed: int = 42,
) -> Dict[str, Dict[str, float]]:
    """
    5-fold stratified cross-validation (Section: "Cross Validation:
    Five-fold / Mean / Standard deviation"). For each fold:
      1. build a fresh model (`build_model_fn`),
      2. build a Trainer wired to that fold's train/val DataLoaders
         (`build_trainer_fn`),
      3. train and record the best validation metrics,
    then aggregate mean +/- std across folds via
    `summarize_cross_validation`.
    """
    skf = StratifiedKFold(n_splits=k, shuffle=True, random_state=seed)
    fold_metrics: List[Dict[str, float]] = []
    indices = list(range(len(dataset)))

    for fold_idx, (train_idx, val_idx) in enumerate(skf.split(indices, labels)):
        train_subset = Subset(dataset, train_idx)
        val_subset = Subset(dataset, val_idx)
        train_loader = DataLoader(train_subset, batch_size=batch_size, shuffle=True)
        val_loader = DataLoader(val_subset, batch_size=batch_size, shuffle=False)

        model = build_model_fn()
        trainer = build_trainer_fn(model, train_loader, val_loader)
        trainer.cfg.run_name = f"{trainer.cfg.run_name}_fold{fold_idx}"
        result = trainer.train()

        val_metrics = trainer.evaluate(val_loader)
        fold_metrics.append(val_metrics)

    return {
        "per_fold": fold_metrics,
        "summary": summarize_cross_validation(fold_metrics),
    }
